@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~dp0bin\dpi.exe' -Verb RunAs"
    exit /b
)
cd /d "%~dp0bin"
dpi.exe
pause